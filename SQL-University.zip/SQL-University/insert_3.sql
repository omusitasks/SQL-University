-- INSERT INTO STUDENTS
INSERT INTO students (student_id, first_name, last_name, date_of_birth, email, phone_number)
VALUES
(1, 'John', 'Doe', '1995-05-23', 'johndoe@example.com', '+1-123-456-7890'),
(2, 'Jane', 'Smith', '1997-02-14', 'janesmith@example.com', '+1-234-567-8901'),
(3, 'Bob', 'Johnson', '1996-09-01', 'bobjohnson@example.com', '+1-345-678-9012'),
(4, 'Sara', 'Lee', '1998-11-30', 'saralee@example.com', '+1-456-789-0123'),
(5, 'David', 'Chang', '1995-08-12', 'davidchang@example.com', '+1-567-890-1234');

-- INSERT INTO ACADEMIC_PROGRAMMES
INSERT INTO academic_programmes (programme_id, programme_name, programme_level)
VALUES
(1, 'MSc Information Science', 'Postgraduate'),
(2, 'BSc Computer Science', 'Undergraduate'),
(3, 'BA English Literature', 'Undergraduate'),
(4, 'MSc Data Science', 'Postgraduate'),
(5, 'PhD Computer Science', 'Doctorate');

-- INSERT INTO ENROLMENTS
INSERT INTO enrolments (enrolment_id, student_id, programme_id, enrolment_year)
VALUES
(1, 1, 1, 2021),
(2, 2, 2, 2020),
(3, 3, 3, 2022),
(4, 4, 4, 2021),
(5, 5, 2, 2019);

-- INSERT INTO MODULES
INSERT INTO modules (module_id, module_name, module_credits, programme_id, year, instructor_id)
VALUES
(1, 'Introduction to Information Science', 10, 1, 2021, 1),
(2, 'Algorithms and Data Structures', 15, 2, 2020, 2),
(3, 'Shakespearean Tragedies', 5, 3, 2022, 3),
(4, 'Data Mining and Machine Learning', 10, 4, 2021, 4),
(5, 'Artificial Intelligence', 15, 2, 2019, 5);

-- INSERT INTO INSTRUCTORS
INSERT INTO instructors (instructor_id, first_name, last_name, email, phone_number)
VALUES
(1, 'Maria', 'Gonzalez', 'mariagonzalez@example.com', '+1-111-111-1111'),
(2, 'John', 'Smith', 'johnsmith@example.com', '+1-222-222-2222'),
(3, 'Sarah', 'Brown', 'sarahbrown@example.com', '+1-333-333-3333'),
(4, 'James', 'Lee', 'jameslee@example.com', '+1-444-444-4444'),
(5, 'Karen', 'Kim', 'karenkim@example.com', '+1-555-555-5555');


-- INSERT INTO module_enrolments
INSERT INTO module_enrolments (enrolment_id, student_id, module_id, year, instructor_id)
VALUES
(1, 1, 1, 2021, 1),
(2, 1, 2, 2021, 2),
(3, 2, 2, 2020, 2),
(4, 3, 3, 2022, 3),
(5, 4, 4, 2021, 4),
(6, 5, 5, 2019, 5);
